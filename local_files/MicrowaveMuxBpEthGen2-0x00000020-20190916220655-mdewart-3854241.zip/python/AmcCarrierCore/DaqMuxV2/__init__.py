#!/usr/bin/env python

from AmcCarrierCore.DaqMuxV2._DaqMuxV2 import *
