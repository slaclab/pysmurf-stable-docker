#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : Parrallel Eta Scan Process
#-----------------------------------------------------------------------------
# File       : ParrallelEtaScan.py
# Created    : 2019-10-09
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to 
# the license terms in the LICENSE.txt file found in the top-level directory 
# of this distribution and at: 
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html. 
# No part of the rogue software platform, including this file, may be 
# copied, modified, propagated, or distributed except according to the terms 
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------
import rogue.interfaces.memory as rim
import collections
import datetime
import functools as ft
import pyrogue as pr
import inspect
import threading
import math
import time

class ParrallelEtaScan(pr.Process):
    def __init__(self, **kwargs):
        pr.Process.__init__(self)

    def _process(self):
        self.parent.etaScanInProgress.set( 1 )
        self.Message.setDisp("Started")

        # defer update callbacks
        with self.root.updateGroup():
            self.Message.setDisp("Init")
            delF            = self.parent.etaScanDelF.get()*1e-6
            numAverages     = 10

            amplitudeScaleArray = np.asarray(self.parent.amplitudeScaleArray.get())
            amplIdx = np.where( amplitudeScaleArray == 0 )

            self.parent.feedbackEnableArray.set( [0 for _ in range(512)] )

            self.parent.etaMagArray.set( [1 for _ in range(512)] )

            self.parent.etaPhaseArray.set( [0 for _ in range(512)] )
            time.sleep(0.1)
            imag = np.mean( [ self.parent.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )

            self.parent.etaPhaseArray.set( [-90 for _ in range(512)] )
            time.sleep(0.1)
            real = np.mean( [ self.parent.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )

            etaPhaseDegree = np.arctan2(imag, real)*180/np.pi

            idx = np.where( etaPhaseDegree > 180 )
            etaPhaseDegree[idx] = etaPhaseDegree[idx] - 360

            idx = np.where( etaPhaseDegree < -180 )
            etaPhaseDegree[idx] = etaPhaseDegree[idx] + 360

            etaPhaseDegree[amplIdx] = 0
            self.parent.etaPhaseArray.set( etaPhaseDegree )

            freq = np.asarray( self.parent.centerFrequencyArray.get() )

            self.parent.centerFrequencyArray.set( freq + delF )
            time.sleep(0.1)
            posError = np.mean( [ self.parent.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )

            self.parent.centerFrequencyArray.set( freq - delF )
            time.sleep(0.1)
            negError = np.mean( [ self.parent.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )

            self.parent.centerFrequencyArray.set( freq )

            etaMagScaled = 2*delF / ( posError - negError )
            idx = np.where( etaMagScaled < 0 )
            etaMagScaled[idx] = np.abs( etaMagScaled[idx] )
            etaPhaseDegree[idx] = etaPhaseDegree[idx] + 180

            idx = np.where( etaPhaseDegree > 180 )
            etaPhaseDegree[idx] = etaPhaseDegree[idx] - 360

            idx = np.where( etaPhaseDegree < -180 )
            etaPhaseDegree[idx] = etaPhaseDegree[idx] + 360

            etaPhaseDegree[amplIdx] = 0
            etaMagScaled[amplIdx] = 0

            self.parent.etaPhaseArray.set( etaPhaseDegree )

            self.parent.etaMagArray.set( etaMagScaled )

            feedbackEnable = [1 for _ in range(512)]
            feedbackEnable[amplIdx] = 0
            self.parent.feedbackEnableArray.set( feedbackEnable )

        self.Progress.set(1.0)
        self.Message.setDisp(f"Done")
        self.parent.etaScanInProgress.set( 0 )

