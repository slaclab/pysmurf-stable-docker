#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# File       : SysgenCryo.py
# Created    : 2017-04-03
#-----------------------------------------------------------------------------
# Description:
# PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to
# the license terms in the LICENSE.txt file found in the top-level directory
# of this distribution and at:
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html.
# No part of the rogue software platform, including this file, may be
# copied, modified, propagated, or distributed except according to the terms
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------

import pyrogue as pr
import time
import math
import numpy as np

from CryoDet.DspCoreLib.CryoDetCmbHcd._CryoFreqBand import CryoFreqBand

class SysgenCryo(pr.Device):
    def __init__(   self,
            name        = "SysgenCryo",
            numberPairs = 1,
            enableDeps  = None,
            description = "Cryo SYSGEN Module",
            **kwargs):
        super().__init__(name=name, description=description, **kwargs)

        bandCenters = [4250.0, 4750.0, 5250.0, 5750.0, 6250.0, 6750.0, 7250.0, 7750.0]
        bandOffsets = [0x000000, 0x100000, 0x200000, 0x300000, 0x800000, 0x900000, 0xA00000, 0xB00000]

        ##############################
        # Devices
        ##############################
        for i in range(8):
            enable = None
            if enableDeps != None:
                enable = enableDeps[i]

            self.add(CryoFreqBand(
                name       = ('Base[%d]'%i),
                bandCenter = bandCenters[i],
                band       = i,
                offset     = bandOffsets[i],
                enableDeps = [enable],
                expand     = False,
            ))

        self.add(pr.LocalVariable(
             name        = "tuneFilePath",
             description = "tune file",
             mode        = "RW",
             value       = "",
        ))
