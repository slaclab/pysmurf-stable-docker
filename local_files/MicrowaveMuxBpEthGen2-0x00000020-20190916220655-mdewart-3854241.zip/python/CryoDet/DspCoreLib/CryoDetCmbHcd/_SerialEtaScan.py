#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : Serial Eta Scan Process
#-----------------------------------------------------------------------------
# File       : SerialEtaScan.py
# Created    : 2019-10-09
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to 
# the license terms in the LICENSE.txt file found in the top-level directory 
# of this distribution and at: 
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html. 
# No part of the rogue software platform, including this file, may be 
# copied, modified, propagated, or distributed except according to the terms 
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------
import rogue.interfaces.memory as rim
import collections
import datetime
import functools as ft
import pyrogue as pr
import inspect
import threading
import math
import time

class SerialEtaScan(pr.Process):
    def __init__(self, **kwargs):
        pr.Process.__init__(self)

    def _process(self):
        self.parent.etaScanInProgress.set( 1 )
        self.Message.setDisp("Started")

        # defer update callbacks
        with self.root.updateGroup():
            self.Message.setDisp("Init")

            delF            = self.parent.etaScanDelF.get()*1e-6

            numAverages     = self.parent.etaScanAverages.get()

            amplitudeScale  = self.parent.amplitudeScaleArray.get()

            freq            = self.parent.centerFrequencyArray.get()

            self.parent.feedbackEnableArray.set( [0 for _ in range(512)] )

            self.parent.etaMagArray.set( [1 for _ in range(512)] )

            self.parent.etaPhaseArray.set( [0 for _ in range(512)] )

            self.parent.amplitudeScaleArray.set( [0 for _ in range(512)] )

            channels = np.where( np.asarray(amplitudeScale) != 0 )

            tot = len(channels[0])
            for channel in channels[0]:
                self.Message.setDisp(f"Channel {channel}")
                self.Progress.set(channel/tot)

                self.parent.CryoChannel[channel].amplitudeScale.set( amplitudeScale[channel] )
                imag = np.mean([self.parent.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                self.parent.CryoChannel[channel].etaPhaseDegree.set( -90 )
                real = np.mean([self.parent.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                etaPhaseDegree = np.arctan2(imag, real)*180/np.pi
                if etaPhaseDegree > 180:
                   etaPhaseDegree = etaPhaseDegree - 360
                elif etaPhaseDegree < -180:
                   etaPhaseDegree = etaPhaseDegree + 360
                self.parent.CryoChannel[channel].etaPhaseDegree.set( etaPhaseDegree )

                self.parent.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] + delF )
                posError = np.mean([self.parent.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                self.parent.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] - delF )
                negError = np.mean([self.parent.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                self.parent.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] )
                etaMagScaled = 2*delF / ( posError - negError )
                if etaMagScaled < 0:
                    etaMagScaled = np.abs( etaMagScaled )
                    if etaPhaseDegree > 0:
                        etaPhaseDegree = etaPhaseDegree - 180
                    else:
                        etaPhaseDegree = etaPhaseDegree + 180

                self.parent.CryoChannel[channel].etaPhaseDegree.set( etaPhaseDegree )
                self.parent.CryoChannel[channel].etaMagScaled.set( etaMagScaled )

                self.parent.CryoChannel[channel].amplitudeScale.set( 0 )

            self.parent.amplitudeScaleArray.set( amplitudeScale )
            time.sleep(0.1)

            for channel in channels[0]:
                self.parent.CryoChannel[channel].feedbackEnable.set( 1 )

            #feedbackEnable = [0 for _ in range(512)]
            #feedbackEnable[channels[0]] = 1
            #self.parent.feedbackEnableArray.set( feedbackEnable )

        self.Progress.set(1.0)
        self.Message.setDisp(f"Done")
        self.parent.etaScanInProgress.set( 0 )

