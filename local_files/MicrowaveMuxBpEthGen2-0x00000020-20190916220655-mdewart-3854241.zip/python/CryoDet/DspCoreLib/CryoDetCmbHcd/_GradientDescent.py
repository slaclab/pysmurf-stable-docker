#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : Gradient Descent Process
#-----------------------------------------------------------------------------
# File       : GradientDescent.py
# Created    : 2019-10-09
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to 
# the license terms in the LICENSE.txt file found in the top-level directory 
# of this distribution and at: 
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html. 
# No part of the rogue software platform, including this file, may be 
# copied, modified, propagated, or distributed except according to the terms 
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------
import rogue.interfaces.memory as rim
import collections
import datetime
import functools as ft
import pyrogue as pr
import inspect
import threading
import math
import time

class GradientDescent(pr.Process):
    def __init__(self, **kwargs):
        pr.Process.__init__(self)

    def _process(self):
        self.parent.etaScanInProgress.set( 1 )
        self.Message.setDisp("Started")

        # defer update callbacks
        with self.root.updateGroup():
            amplitudeScaleArray = np.asarray(self.parent.amplitudeScaleArray.get())
            amplIdx = np.where( amplitudeScaleArray != 0 )

            self.parent.feedbackEnableArray.set( [0 for _ in range(512)] )

            self.parent.etaMagArray.set( [1 for _ in range(512)] )

            freq = np.asarray( self.parent.centerFrequencyArray.get() )
            iters     = 0
            max_iters = 10
            l         = 0.005

            # get nominal response
            self.Message.setDisp("Nominal Response")
            prevDf   = np.zeros( np.shape(freq) )
            self.parent.etaPhaseArray.set( [0 for _ in range(512)] )
            prevResp = 1j*np.asarray(self.parent.frequencyErrorArray.get(read=True))
            self.parent.etaPhaseArray.set( [-90 for _ in range(512)] )
            prevResp += np.asarray(self.parent.frequencyErrorArray.get(read=True))
            self.Progress.set(0.1)

            # get response 5kHz away
            self.Message.setDisp("5Khz Response")
            currDf           = np.zeros( np.shape(freq) )
            currDf[amplIdx]  = 0.005
            self.parent.centerFrequencyArray.set( freq + currDf )
            self.parent.etaPhaseArray.set( [0 for _ in range(512)] )
            currResp = 1j*np.asarray(self.parent.frequencyErrorArray.get(read=True))
            self.parent.etaPhaseArray.set( [-90 for _ in range(512)] )
            currResp += np.asarray(self.parent.frequencyErrorArray.get(read=True))
            self.Progress.set(0.2)

            step = currDf - prevDf

            while iters < max_iters:
                self.Message.setDisp(f"Iter {iters}")
                step      = currDf - prevDf 
                prevDf = currDf
                currDf[amplIdx] -= l * ( np.abs(currResp[amplIdx]) - np.abs(prevResp[amplIdx]) ) / step[amplIdx]
                prevResp = currResp
                self.parent.centerFrequencyArray.set( freq + currDf )
                self.parent.etaPhaseArray.set( [0 for _ in range(512)] )
                currResp = 1j*np.asarray(self.parent.frequencyErrorArray.get(read=True))
                self.parent.etaPhaseArray.set( [-90 for _ in range(512)] )
                currResp += np.asarray(self.parent.frequencyErrorArray.get(read=True))
                iters += 1
                self.Progress.set(0.2 + (0.8 * (max_iters/iters)))

        self.Progress.set(1.0)
        self.Message.setDisp("Done!")
        self.parent.etaScanInProgress.set( 0 )

