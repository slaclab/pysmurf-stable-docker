#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# File       : SysgenCryo.py
# Created    : 2017-04-03
#-----------------------------------------------------------------------------
# Description:
# PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to
# the license terms in the LICENSE.txt file found in the top-level directory
# of this distribution and at:
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html.
# No part of the rogue software platform, including this file, may be
# copied, modified, propagated, or distributed except according to the terms
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------

import pyrogue as pr
import time
import math
import numpy as np

class CryoChannel(pr.Device):
    def __init__(   self,
            name        = "Cryo frequency cord",
            description = "Note: This module is read-only with respect to sysgen",
            hidden      = True,
            index       = 0,
            parent      = None,
            **kwargs):
        super().__init__(name=name, description=description, hidden=hidden, **kwargs)

        freqSpanMHz = 9.6
        ##############################
        # Configuration registers (RO from Sysgen)
        ##############################
        i = index
        self.add(pr.LinkVariable(
            name         = "etaMagScaled",
            description  = "ETA mag scaled",
            dependencies = [parent.node(f'etaMag[{i}]')],
            linkedGet    = lambda var: var.dependencies[0].value()*2**-10,
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int(round(value*2**10)), write=write),
            typeStr      = "Float64",
        ))

        self.add(pr.LinkVariable(
            name         = "etaPhaseDegree",
            description  = "ETA phase degrees",
            dependencies = [parent.node(f'etaPhase[{i}]')],
            linkedGet    = lambda var: var.dependencies[0].value()*180*2**-15,
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int(round(value*2**15./180)), write=write),
            typeStr      = "Float64",
        ))

        # Cryo channel frequency word
        self.add(pr.LinkVariable(
            name         = "feedbackEnable",
            description  = "Enable feedback on this channel UFix_1_0",
            variable     = parent.node(f'feedbackEnable[{i}]'),
            typeStr      = "UInt1",
        ))

        self.add(pr.LinkVariable(
            name         = "amplitudeScale",
            description  = "Amplitdue scale UFix_4_0",
            variable     = parent.node(f'amplitudeScale[{i}]'),
            typeStr      = "UInt4",
        ))

        self.add(pr.LinkVariable(
            name         = "centerFrequencyMHz",
            description  = "Center frequency MHz",
            dependencies = [parent.node(f'centerFrequency[{i}]')],
            linkedGet    = lambda var: var.dependencies[0].value()*2**-24*freqSpanMHz,
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int(round((value*2**24./freqSpanMHz))), write=write),
            typeStr      = "Float64",
        ))

        # Cryo channel readback loop filter output
        self.add(pr.LinkVariable(
            name         = "loopFilterOutput",
            description  = "Loop filter output UFix_24_24",
            variable     = parent.node(f'loopFilterOutput[{i}]'),
            typeStr      = "Int24",
        ))

        self.add(pr.LinkVariable(
            name         = "amplitudeReadback",
            description  = "Loop filter output UFix_4_0",
            variable     = parent.node(f'amplitudeScale[{i}]'),
            typeStr      = "UInt4",
        ))

        self.add(pr.LinkVariable(
            name         = "frequencyErrorMHz",
            description  = "Frequency error Fix_24_23",
            mode         = "RO",
            dependencies = [parent.node(f'frequencyError[{i}]')],
            linkedGet    = lambda var, read: var.dependencies[0].get(read=read)*2**-23*freqSpanMHz,
            typeStr      = "Float64",
        ))

        self.add(pr.LinkVariable(
            name         = "frequencyError",
            hidden       = True,
            description  = "Frequency error Fix_24_23",
            mode         = "RO",
            variable     = parent.node(f'frequencyError[{i}]'),
            linkedGet    = lambda var, read: var.dependencies[0].get(read=read),
            typeStr      = "Float64",
        ))

