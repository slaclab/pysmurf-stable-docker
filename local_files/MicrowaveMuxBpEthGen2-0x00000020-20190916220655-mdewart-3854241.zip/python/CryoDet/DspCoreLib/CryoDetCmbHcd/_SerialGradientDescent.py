#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : Serial Gradient Descent Process
#-----------------------------------------------------------------------------
# File       : SerialGradientDescent.py
# Created    : 2019-10-09
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to 
# the license terms in the LICENSE.txt file found in the top-level directory 
# of this distribution and at: 
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html. 
# No part of the rogue software platform, including this file, may be 
# copied, modified, propagated, or distributed except according to the terms 
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------
import rogue.interfaces.memory as rim
import collections
import datetime
import functools as ft
import pyrogue as pr
import inspect
import threading
import math
import time

class SerialGradientDescent(pr.Process):
    def __init__(self, **kwargs):
        pr.Process.__init__(self)

    def _process(self):
        self.parent.etaScanInProgress.set( 1 )
        self.Message.setDisp("Started")

        def calcGrad(root, channel, centerFrequencyMHz, measDf, numAverages):
            df = measDf
            root.CryoChannel[channel].centerFrequencyMHz.set( centerFrequencyMHz + df )
            root.CryoChannel[channel].etaPhaseDegree.set( 0 )
            posResp = np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
            root.CryoChannel[channel].etaPhaseDegree.set( 90 )
            posResp += 1j*np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])

            root.CryoChannel[channel].centerFrequencyMHz.set( centerFrequencyMHz - df )
            root.CryoChannel[channel].etaPhaseDegree.set( 0 )
            negResp = np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
            root.CryoChannel[channel].etaPhaseDegree.set( 90 )
            negResp += 1j*np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])

            grad = ( np.abs(posResp) - np.abs(negResp) ) / ( 2*df )

            return grad

        # defer update callbacks
        with self.root.updateGroup():
            self.Message.setDisp("Init")
            iters       = 0
            maxIters    = self.parent.gradientDescentMaxIters.get() 
            l           = self.parent.gradientDescentGain.get()
            numAverages = self.parent.gradientDescentAverages.get()
            momentum    = self.parent.gradientDescentMomentum.get() 
            initialStep = self.parent.gradientDescentStepHz.get()*1e-6
            converge    = self.parent.gradientDescentConvergeHz.get()*1e-6
            beta        = self.parent.gradientDescentBeta.get()
            debug       = self.parent.debug.get()

            amplitudeScale = self.parent.amplitudeScaleArray.get()

            freq           = self.parent.centerFrequencyArray.get()

            self.parent.feedbackEnableArray.set( [0 for _ in range(512)] )

            self.parent.amplitudeScaleArray.set( [0 for _ in range(512)] )

            self.parent.etaMagArray.set( [1 for _ in range(512)] )

            self.parent.etaPhaseArray.set( [0 for _ in range(512)] )

            channels = np.where( np.asarray(amplitudeScale) != 0 )

            tot = len(channels[0])
            for channel in channels[0]:
                self.Message.setDisp(f"Tuning Channel {channel}")
                self.Progress.set((channel*maxIters)/(tot*maxIters))
                if ( debug == True):
                    print(" ")
                    print(" ")
                    print("Tuning channel " + str(channel))
                    print(" ")
                    print(" ")
                prevDf = 0
                currDf = 0
                self.parent.CryoChannel[channel].amplitudeScale.set( amplitudeScale[channel] )

                v     = 0
                iters = 0
                cache = 0
                complete = False
                while (iters < maxIters):
                    self.Progress.set((channel*(maxIters+iters))/(tot*maxIters))
                    #print( str(np.abs(currResp)) + ", " + str(currDf) + ", " + str(step) )
                    prevDf = currDf
                    dx     = calcGrad( self.parent, channel, freq[channel] + currDf, initialStep, numAverages ) # center difference
                    if momentum == 1:
                        v = beta*v + (1-beta)* l * dx
                        currDf -= v
                    else:
                        #cache   += dx**2
                        cache   = beta * cache + (1 - beta) * dx**2
                        currDf -= l * dx / np.sqrt( cache + 1e-8 )
                    step   = currDf - prevDf
                    if ( debug == True ):
                        print("Grad is " + str(dx) + ", step is " + str(step) + " currDf is " + str(currDf))
                    if np.abs(step) < converge:
                        complete = True
                        self.parent.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] + currDf )
                        break
                    iters += 1

                    if ( ( ( freq[channel] + currDf ) > 2.4e6 ) | ( ( freq[channel] + currDf ) < -2.4e6 ) ):
                        self.parent.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] )
                        print("Channel " + str(channel) + " failed to converge")
                        break

                if ( debug == True ):
                    if (complete == False):
                        print("Channel " + str(channel) + " failed to converge")
                    else:
                        print("Channel " + str(channel) + " converged after " + str(iters) + " iterations")
     
                self.parent.CryoChannel[channel].amplitudeScale.set( 0 )

            self.parent.amplitudeScaleArray.set( amplitudeScale )

        self.Progress.set(1.0)
        self.Message.setDisp(f"Done")
        self.parent.etaScanInProgress.set( 0 )

