#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# File       : SysgenCryo.py
# Created    : 2017-04-03
#-----------------------------------------------------------------------------
# Description:
# PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to
# the license terms in the LICENSE.txt file found in the top-level directory
# of this distribution and at:
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html.
# No part of the rogue software platform, including this file, may be
# copied, modified, propagated, or distributed except according to the terms
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------

import pyrogue as pr
import time
import math
import numpy as np

from CryoDet.DspCoreLib.CryoDetCmbHcd._CryoChannels import CryoChannels

class CryoFreqBand(pr.Device):
    def __init__(   self,
            name        = "SysgenCryoBase",
            bandCenter  = 4250.0,
            description = "Cryo SYSGEN Module",
            band        = 1,
            enableDeps  = None,
            **kwargs):
        super().__init__(name=name, description=description, enableDeps=enableDeps, **kwargs)

        def genCenterFrequencies():
           def bitRevOrder(x):
              length = x.shape[0]
              assert( np.log2(length) == np.floor(np.log2(length)) )

              if length == 1:
                 return x
              else:
                 evenIndex = np.arange(length/2)*2
                 oddIndex  = np.arange(length/2)*2 + 1
                 evens     = bitRevOrder( x[evenIndex.astype(int)] )
                 odds      = bitRevOrder( x[oddIndex.astype(int)] )
                 return np.concatenate([evens, odds])

           fAdc          = 614.4      # digitizer frequency MHz
           fftLen        = 64         # fft length
           nFft          = 2          # interleaved polyphase filter bank
           nTones        = 4          # 4 tones/subband
           bands         = np.arange(64) * fAdc/fftLen
           bandsRevOrder = bands[ bitRevOrder( np.arange(64) ) ]
           bandsTile1    = np.tile(bandsRevOrder, nTones) 
           bandsTile2    = np.concatenate([bandsTile1, bandsTile1 + fAdc/(fftLen*nFft)])
        
           bandsCenter   = bandsTile2
           index         = np.where( bandsCenter > fAdc/2 )
           bandsCenter[index]  = bandsCenter[index] - fAdc
           return bandsCenter.tolist()

        #self.p = parent
        ##############################
        # Freq band parameters
        ##############################

        self.add(pr.LocalVariable(
            name        = "band",
            description = "band",
            mode        = "RO",
            value       = band,
        ))

        self.add(pr.LocalVariable(
            name        = "digitizerFrequencyMHz",
            description = "ADC/DAC sampling rate MHz",
            mode        = "RO",
            value       = 614.4,
        ))

        self.add(pr.LocalVariable(
            name        = "channelFrequencyMHz",
            description = "channel processing rate MHz",
            mode        = "RO",
            value       = 2.4,
        ))

        self.add(pr.LocalVariable(
            name        = "bandCenterMHz",
            description = "bandCenter MHz",
            mode        = "RW",
            value       = bandCenter,
        ))

        self.add(pr.LocalVariable(
            name        = "numberChannels",
            description = "number of channels",
            mode        = "RO",
            value       = 512,
        ))

        self.add(pr.LocalVariable(
            name        = "numberSubBands",
            description = "number of DSP sub bands",
            mode        = "RO",
            value       = 128,
        ))

        self.add(pr.LocalVariable(
            name        = "toneFrequencyOffsetMHz",
            description = "frequency to subband",
            mode        = "RO",
            value       = [round(x,1) for x in genCenterFrequencies()],
        ))

        ##############################
        # Devices
        ##############################
        self.add(CryoChannels(
            name   = 'CryoChannels',
            offset = 0x00010000,
            expand = False,
        ))

        ##############################
        # Registers
        ##############################
        self.add(pr.RemoteVariable(
            name         = "VersionNumber",
            description  = "Version Number",
            offset       =  0x000,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RO",
        ))

        self.add(pr.RemoteVariable(
            name         = "ScratchPad",
            description  = "Scratch Pad Register",
            offset       =  0xFFC,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

## config0
        self.add(pr.RemoteVariable(
            name         = "waveformSelect",
            description  = "Select waveform table",
            offset       =  0x80,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
        self.add(pr.RemoteVariable(
            name         = "noiseSelect",
            description  = "Play uniformly distributed PRNG",
            offset       =  0x80,
            bitSize      =  1,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))
        self.add(pr.RemoteVariable(
            name         = "rfEnable",
            description  = "Enable RF output",
            offset       =  0x80,
            bitSize      =  1,
            bitOffset    =  2,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config0  end

## config1
        self.add(pr.RemoteVariable(
            name         = "iqSwapOut",
            description  = "Swap IQ channels on output",
            offset       =  0x84,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "iqSwapIn",
            description  = "Swap IQ channels on input",
            offset       =  0x84,
            bitSize      =  1,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config1  end

## config2
        self.add(pr.RemoteVariable(
            name         = "refPhaseDelayInt",
            description  = "refPhaseDelay",
            offset       =  0x118,
            hidden       = True,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
   
        self.add(pr.LinkVariable(
            dependencies = [self.refPhaseDelayInt],
            linkedGet    = lambda var: int((var.dependencies[0].value() + 6)/208),
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int((value*208)-6), write=write),
            typeStr      = "UInt4",
            name         = "refPhaseDelay",
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "toneScale",
            description  = "Scale the sum of 16 tones before synthesizer",
            offset       =  0x88,
            bitSize      =  2,
            bitOffset    =  3,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackEnable",
            description  = "Global feedback enable",
            offset       =  0x88,
            bitSize      =  1,
            bitOffset    =  5,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackPolarity",
            description  = "Global feedback polarity",
            offset       =  0x88,
            bitSize      =  1,
            bitOffset    =  6,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "swapDfIQ",
            description  = "Swap DF IQ",
            offset       =  0x88,
            bitSize      =  1,
            bitOffset    =  7,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "statusChannelSelect",
            description  = "Select channel for status registers",
            offset       =  0x88,
            bitSize      =  9,
            bitOffset    =  8,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config2  end

## config3
        self.add(pr.RemoteVariable(
            name         = "feedbackGain",
            description  = "Feedback gain UFix_16_12",
            offset       =  0x8C,
            bitSize      =  16,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
        self.add(pr.RemoteVariable(
            name         = "feedbackLimit",
            description  = "Feedback limit UFix_16_16",
            offset       =  0x8C,
            bitSize      =  16,
            bitOffset    =  16,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config3  end

## config4
        self.add(pr.RemoteVariable(
            name         = "filterAlpha",
            description  = "IIR filter alpha UFix16_15",
            offset       =  0x90,
            bitSize      =  16,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

## config4 end
        self.add(pr.RemoteVariable(
            name         = "loopFilterOutputSel",
            description  = "Global loop filter out reg.  Select with ",
            offset       =  0x94,
            bitSize      =  7,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "analysisScale",
            description  = "analysis filter bank scale, nominal value is 1",
            offset       =  0x98,
            bitSize      =  2,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "synthesisScale",
            description  = "synthesis filter bank scale, nominal value is 2",
            offset       =  0x98,
            bitSize      =  2,
            bitOffset    =  2,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "decimation",
            description  = "debug decimation rate 0...7",
            offset       =  0x98,
            bitSize      =  3,
            bitOffset    =  4,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "singleChannelReadout",
            description  = "select for single channel readout",
            offset       =  0x9C,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "singleChannelReadoutOpt2",
            description  = "non-decimated single channel readout - rate 307.2e6/128",
            offset       =  0x9C,
            bitSize      =  1,
            bitOffset    =  10,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "iqStreamEnable",
            description  = "readout IQ data instead of freq/freqError",
            offset       =  0x9C,
            bitSize      =  1,
            bitOffset    =  11,
            base         = pr.UInt,
            mode         = "RW",
        ))


        self.add(pr.RemoteVariable(
            name         = "readoutChannelSelect",
            description  = "select for single channel readout",
            offset       =  0x9C,
            bitSize      =  9,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))



        self.add(pr.RemoteVariable(
            name         = "dspReset",
            description  = "reset DSP core",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "dspEnable",
            description  = "Enable DSP core",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))


        self.add(pr.RemoteVariable(
            name         = "refPhaseDelayFine",
            description  = "fine delay control (307.2MHz clock)",
            offset       =  0x100,
            bitSize      =  8,
            bitOffset    =  2,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "trigRstDly",
            description  = "Trigger reset delay (2.4MHz ticks)",
            offset       =  0x10C,
            bitSize      =  7,
            bitOffset    =  5,
            base         = pr.UInt,
            mode         = "RW",
        ))


        self.add(pr.RemoteVariable(
            name         = "lmsDelay",
            description  = "Match system latency for LMS feedback (9.6MHz ticks, use multiples of 52)",
            offset       =  0x10C,
            bitSize      =  5,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackStart",
            description  = "Start integration UFix32",
            offset       =  0x110,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackEnd",
            description  = "End integration UFix32",
            offset       =  0x114,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
   

        self.add(pr.RemoteVariable(
            name         = "lmsGain",
            description  = "LMS gain, powers of 2",
            offset       =  0x100,
            bitSize      =  3,
            bitOffset    =  10,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsEnable1",
            description  = "Enable 1st harmonic tracking",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  16,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsEnable2",
            description  = "Enable 2nd harmonic tracking",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  17,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsEnable3",
            description  = "Enable 3rd harmonic tracking",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  18,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsFreq",
            description  = "LMS frequency = flux ramp freq * nPhi0",
            offset       =  0x104,
            bitSize      =  24,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.LinkVariable(
            name         = "lmsFreqHz",
            description  = "LMS frequency = flux ramp freq * nPhi0",
            dependencies = [self.lmsFreq],
            linkedGet    = lambda: self.lmsFreq.value()*(2**-24)*(9.6*10**6),
            linkedSet    = lambda value, write: self.lmsFreq.set(round(value*(2**24)/(9.6*10**6)), write=write),
            typeStr      = "Float64",
        ))

        self.add(pr.RemoteVariable(
            name         = "streamEnable",
            description  = "Enable streaming",
            offset       =  0x108,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

## status1
        self.add(pr.RemoteVariable(
            name         = "Q",
            description  = "Q readback Fix_16_15",
            offset       =  0x08,
            bitSize      =  16,
            bitOffset    =  0,
            base         = pr.Int,
            mode         = "RO",
##            pollInterval = 1,
        ))
        self.add(pr.RemoteVariable(
            name         = "I",
            description  = "I readback Fix_16_15",
            offset       =  0x08,
            bitSize      =  16,
            bitOffset    =  16,
            base         = pr.Int,
            mode         = "RO",
##            pollInterval = 1,
        ))
## status1 end

## status 2
        self.add(pr.RemoteVariable(
            name         = "dspCounter",
            description  = "32 bit counter, dsp clock domain UFix_32_0",
            offset       =  0x0C,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RO",
        ))
## status2 end
        self.add(pr.RemoteVariable(
            name         = "loopFilterOutput",
            description  = "Loop filter output UFix_32_0",
            offset       =  0x10,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RO",
        ))

