#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# File       : SysgenCryo.py
# Created    : 2017-04-03
#-----------------------------------------------------------------------------
# Description:
# PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to
# the license terms in the LICENSE.txt file found in the top-level directory
# of this distribution and at:
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html.
# No part of the rogue software platform, including this file, may be
# copied, modified, propagated, or distributed except according to the terms
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------

import pyrogue as pr
import time
import math
import numpy as np

from CryoDet.DspCoreLib.CryoDetCmbHcd._CryoChannel           import CryoChannel
from CryoDet.DspCoreLib.CryoDetCmbHcd._GradientDescent       import GradientDescent
from CryoDet.DspCoreLib.CryoDetCmbHcd._SerialGradientDescent import SerialGradientDescent
from CryoDet.DspCoreLib.CryoDetCmbHcd._SerialEtaScan         import SerialEtaScan
from CryoDet.DspCoreLib.CryoDetCmbHcd._ParrallelEtaScan      import ParrallelEtaScan

class CryoChannels(pr.Device):
    def __init__(   self,
            name        = "CryoFrequencyBand",
            description = "Note: This module is read-only with respect to sysgen",
            hidden      = False,
            **kwargs):
        super().__init__(name=name, description=description, hidden=hidden, **kwargs)

        ##############################
        # Devices
        ##############################
        for i in range(512):
            # Cryo channel ETA
            self.add(pr.RemoteVariable(
                name         = f'etaMag[{i}]',
                hidden       = True,
                description  = "ETA mag Fix_16_10",
                offset       =  0x0000 + i*4,
                bitSize      =  16,
                bitOffset    =  0,
                base         = pr.UInt,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'etaPhase[{i}]',
                hidden       = True,
                description  = "ETA phase Fix_16_15",
                offset       =  0x0002 + i*4,
                bitSize      =  16,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RW",
            ))

            # Cryo channel frequency word
            self.add(pr.RemoteVariable(
                name         = f'feedbackEnable[{i}]',
                hidden       = True,
                description  = "Enable feedback on this channel UFix_1_0",
                offset       =  0x0800 + i*4,
                bitSize      =  1,
                bitOffset    =  31,
                base         = pr.UInt,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'amplitudeScale[{i}]',
                hidden       = True,
                description  = "Amplitdue scale UFix_4_0",
                offset       =  0x0800 + i*4,
                bitSize      =  4,
                bitOffset    =  24,
                base         = pr.UInt,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'centerFrequency[{i}]',
                hidden       = True,
                description  = "Center frequency Fix_24_23",
                offset       =  0x0800 + i*4,
                bitSize      =  24,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'amplitudeReadback[{i}]',
                hidden       = True,
                description  = "Loop filter output UFix_4_0",
                offset       =  0x1000 + i*4,
                bitSize      =  4,
                bitOffset    =  24,
                base         = pr.UInt,
                mode         = "RO",
            ))

            # Cryo channel readback loop filter output
            self.add(pr.RemoteVariable(
                name         = f'loopFilterOutput[{i}]',
                hidden       = True,
                description  = "Loop filter output UFix_24_24",
                offset       =  0x1000 + i*4,
                bitSize      =  24,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RO",
            ))

            # Cryo channel readback frequency error
            self.add(pr.RemoteVariable(
                name         = f'frequencyError[{i}]',
                hidden       = True,
                description  = "Frequency error MHz",
                offset       =  0x1800 + i*4,
                bitSize      =  24,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RO",
            ))

            self.add(CryoChannel(
                name   = f'CryoChannel[{i}]',
                offset = (i*0x4),
                hidden = False,
                expand = False,
                index  = i,
                parent = self,
            ))

        # make waveform of etaMag
        self.add(pr.LinkVariable(
            name         = "etaMagArray",
            hidden       = True,
            description  = "eta mag array (scaled)",
            dependencies = [self.node(f'etaMag[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-10 for val in dev.getArray(dev, var, read)],
            linkedSet    = lambda dev, var, value: dev.setArray( dev, var, [int(round(val*2**10)) for val in value]),
            typeStr      = "List[Float64]",
        ))

        # make waveform of etaPhase
        self.add(pr.LinkVariable(
            name         = "etaPhaseArray",
            hidden       = True,
            description  = "eta phase array (degree)",
            dependencies = [self.node(f'etaPhase[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*180*2**-15 for val in dev.getArray(dev, var, read)],
            linkedSet    = lambda dev, var, value: dev.setArray( dev, var, [int(round(val*2**15./180)) for val in value]),
            typeStr      = "List[Float64]",
        ))

        # make waveform of feedbackEnable
        self.add(pr.LinkVariable(
            name         = "feedbackEnableArray",
            hidden       = True,
            description  = "feedback enable array",
            dependencies = [self.node(f'feedbackEnable[{i}]') for i in range(512)],
            linkedGet    = self.getArray,
            linkedSet    = self.setArray,
            typeStr      = "List[UInt1]",
        ))

        # make waveform of amplitudeScale
        self.add(pr.LinkVariable(
            name         = "amplitudeScaleArray",
            hidden       = True,
            description  = "amplitude scale array (0...15)",
            dependencies = [self.node(f'amplitudeScale[{i}]') for i in range(512)],
            linkedGet    = self.getArray,
            linkedSet    = self.setArray,
            typeStr      = "List[UInt4]",
        ))

        # make waveform of centerFrequencyMHz
        self.add(pr.LinkVariable(
            name         = "centerFrequencyArray",
            hidden       = True,
            description  = "center frequency array (MHz)",
            dependencies = [self.node(f'centerFrequency[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-24*9.6 for val in dev.getArray(dev, var, read)],
            linkedSet    = lambda dev, var, value: dev.setArray( dev, var, [int(round(val*2**24./9.6)) for val in value]),
            typeStr      = "List[Float64]",
        ))

        # make waveform of frequencyError
        self.add(pr.LinkVariable(
            name         = "frequencyErrorArray",
            hidden       = True,
            description  = "frequency error array (MHz)",
            dependencies = [self.node(f'frequencyError[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-23*9.6 for val in dev.getArray(dev, var, read)],
            typeStr      = "List[Float64]",
        ))

        # make waveform of frequencyError
        self.add(pr.LinkVariable(
            name         = "loopFilterOutputArray",
            hidden       = True,
            description  = "loop filter output array (MHz)",
            dependencies = [self.node(f'loopFilterOutput[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-23*9.6 for val in dev.getArray(dev, var, read)],
            typeStr      = "List[Float64]",
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanChannel",
            description = "etaScan frequency band",
            mode        = "RW",
            value       = 0,
        ))

        # keeps track of whether or not an etaScan is currently
        # in progress.  default zero, meaning scan isn't running
        # currently.  runEtaScan sets it to one while it's scanning
        self.add(pr.LocalVariable(
            name        = "etaScanInProgress",
            description = "etaScan in progress",
            mode        = "RW",
            value       = 0,
        ))

        # make waveform for etaScanFreqs, 1000 will be our max number
        # make sure to initialize with type we want in EPICS (float)
        self.add(pr.LocalVariable(
            name        = "etaScanFreqs",
            hidden      = True,
            description = "etaScan frequencies",
            mode        = "RW",
            value       = [0.0 for x in range(1000)],
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanResultsImag",
            hidden      = True,
            description = "etaScan frequencies",
            mode        = "RW",
            value       = [0.0 for x in range(1000)],
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanResultsReal",
            hidden      = True,
            description = "etaScan frequencies",
            mode        = "RW",
            value       = [0.0 for x in range(1000)],
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanDelF",
            description = "etaScan frequencies",
            mode        = "RW",
            value       = 5000,
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanDwell",
            description = "etaScan frequencies",
            mode        = "RW",
            value       = 0.0,
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanAmplitude",
            description = "number of points to average for etaScan",
            mode        = "RW",
            value       = 0,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentMaxIters",
            description = "gradient descent max iterations",
            mode        = "RW",
            value       = 15,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentAverages",
            description = "gradient descent number of averages",
            mode        = "RW",
            value       = 2,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentGain",
            description = "Gradient descent gain",
            mode        = "RW",
            value       = 0.001,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentConvergeHz",
            description = "Use gradient convergence threshold",
            mode        = "RW",
            value       = 500.0,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentStepHz",
            description = "Use gradient descent initial step",
            mode        = "RW",
            value       = 5000.0,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentMomentum",
            description = "Use gradient descent momentum",
            mode        = "RW",
            value       = 1,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentBeta",
            description = "Use gradient descent initial step",
            mode        = "RW",
            value       = 0.1,
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanAverages",
            description = "eta scan number of averages",
            mode        = "RW",
            value       = 2,
        ))

        self.add(pr.LocalVariable(
            name        = "debug",
            description = "print debug messages",
            mode        = "RW",
            value       = 0,
        ))

        # Background Processes
        self.add(GradientDescent())
        self.add(SerialGradientDescent())
        self.add(SerialEtaScan())
        self.add(ParrallelEtaScan())


        @self.command(description="Load ETA params")
        def loadTuneFile():

            band     = self.parent.band.get()
            tuneFile = self.parent.parent.tuneFilePath.get()
            print( "Tuning band " + str(band) + " with tune file: " + tuneFile )

            try:

                tune = np.load( tuneFile ).item()
                tuneBand = tune[band]

                with self.root.updateGroup():

                    drive = tuneBand['drive']

                    # load parameters, don't write to HW yet
                    for r in  tuneBand['resonances']:
                        channel      = tuneBand['resonances'][r]['channel']
                        etaPhase     = tuneBand['resonances'][r]['eta_phase']
                        etaMagScaled = tuneBand['resonances'][r]['eta_scaled']
                        centerFreq   = tuneBand['resonances'][r]['offset']

                        if channel == -1:
                            continue

                        self.CryoChannel[channel].amplitudeScale.set( drive, write=False )
                        self.CryoChannel[channel].centerFrequencyMHz.set( centerFreq, write=False )
                        self.CryoChannel[channel].etaPhaseDegree.set( etaPhase, write=False )
                        self.CryoChannel[channel].etaMagScaled.set( etaMagScaled, write=False )
                        self.CryoChannel[channel].feedbackEnable.set( 1, write=False )

                    # write to HW, block transaction
                    self.writeBlocks()
                    self.verifyBlocks()
                    self.checkBlocks()

            except:
                print("Failed to load tune for band " + str( band ) )



        @self.command(description="Run etaScan",)
        def runEtaScan():
            self.etaScanInProgress.set( 1 )

            # defer update callbacks
            with self.root.updateGroup():
                subchan = self.etaScanChannel.get()
                ampl    = self.etaScanAmplitude.get()
                freqs   = self.etaScanFreqs.get()
                # workaround for rogue local variables
                # list objects get written as string, not list of float when set by GUI
                if isinstance(freqs, str):
                    freqs = eval(freqs)

                dwell   = self.etaScanDwell.get()
                self.CryoChannel[subchan].amplitudeScale.set( ampl )
                self.CryoChannel[subchan].etaMagScaled.set( 1 )
                self.CryoChannel[subchan].feedbackEnable.set( 0 )

                # run scan in phase
                self.CryoChannel[subchan].etaPhaseDegree.set( 0 )
                resultsReal = []
                f           = []
                for freqMHz in freqs:
                    # is there overhead of setting freqMHz if prevFreqMHz == freqMHz
                    # out list of freqs may do several measurements at a single freq
                    # dont' want to write the same value again
                    if f != freqMHz:
                        f = freqMHz
                        self.CryoChannel[subchan].centerFrequencyMHz.set( f )
                    freqError = self.CryoChannel[subchan].frequencyError.get()
                    resultsReal.append( freqError )

                # run scan in quadrature
                self.CryoChannel[subchan].etaPhaseDegree.set( -90 )
                resultsImag = []
                f           = []
                for freqMHz in freqs:
                    if f != freqMHz:
                        f = freqMHz
                        self.CryoChannel[subchan].centerFrequencyMHz.set( f )
                    freqError = self.CryoChannel[subchan].frequencyError.get()
                    resultsImag.append( freqError )


                self.etaScanResultsReal.set( resultsReal )
                self.etaScanResultsImag.set( resultsImag )

            self.etaScanInProgress.set( 0 )



        @self.command(description="Set all amplitudeScale values",value=0)
        def setAmplitudeScales(arg):
            for c in self.CryoChannel.values():
                c.amplitudeScale.setDisp(arg, write=False)

            # Commit blocks with bulk background writes
            self.writeBlocks()

            # Verify the blocks with background transactions
            self.verifyBlocks()

            # Check write and verify results
            self.checkBlocks()

        @self.command(description="Run gradient descent")
        def runGradientDescent():
            self.GradientDescent.Start()

        @self.command(description="Run serial gradient descent")
        def runSerialGradientDescent():
            if self.etaScanInProgress.get() != 1:
                self.SerialGradientDescent.Start()

        @self.command(description="Run serial eta scan")
        def runSerialEtaScan():
            self.SerialEtaScan.Start()

        @self.command(description="Run parallel eta scan")
        def runParallelEtaScan():
            self.ParrallelEtaScan.Start()

    @staticmethod
    def setArray(dev, var, value):
       # workaround for rogue local variables
       # list objects get written as string, not list of float when set by GUI
       if isinstance(value, str):
           value = eval(value)
       for variable, setpoint in zip( var.dependencies, value ):
           variable.set( setpoint, write=False )
       dev.writeBlocks()
       dev.verifyBlocks()
       dev.checkBlocks()

    @staticmethod
    def getArray(dev, var, read):
       if read:
          dev.readBlocks(variable=var.dependencies)
          dev.checkBlocks(variable=var.dependencies)
       return [variable.value() for variable in var.dependencies]

