#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# File       : AppCore.py
# Created    : 2017-04-03
#-----------------------------------------------------------------------------
# Description:
# PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to
# the license terms in the LICENSE.txt file found in the top-level directory
# of this distribution and at:
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html.
# No part of the rogue software platform, including this file, may be
# copied, modified, propagated, or distributed except according to the terms
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------

import pyrogue as pr

import AmcCarrierCore.AppTop                                             as AppTop
from AmcCarrierCore.AppHardware.AmcMicrowaveMux._amcMicrowaveMuxCore import *
from AmcCarrierCore.AppHardware.RtmCryoDet._rtmCryoDet               import *
from CryoDet.MicrowaveMuxApp._TimingHeader                           import TimingHeader

class AppCore(AppTop.AppCore):
    def __init__(   self,
            name        = "AppCore",
            offset      =  0x00000000,
            description = "MicrowaveMux Application",
            numRxLanes  =  [0,0],
            numTxLanes  =  [0,0],
            sysgenClass = None,
            **kwargs):
        super().__init__(name=name,
                         description=description,
                         offset=offset,
                         numRxLanes=numRxLanes,
                         numTxLanes=numTxLanes,
                         **kwargs)

        self.add(pr.RemoteVariable(
            name         = "BUILD_DSP_G",
            description  = "Indicates which DSP cores are built",
            offset       = 0x0300000C,
            bitSize      = 8,
            bitOffset    = 0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        # Workaround: the variable will be accessed before the root
        # is started, so, we need to handle the error in that case
        def bDspGet(read, i):
            r = self.BUILD_DSP_G.get(read=read)
            if r is None:
                return 0
            else:
                return (r >> i) & 1

        self.enableDeps = []
        for i in range(8):
            self.enableDeps.append(
                pr.LinkVariable(
                    name         = f'BUILD_DSP_G_{i}',
                    description  = "Indicates which DSP cores are built",
                    mode         = "RO",
                    hidden       = True,
                    dependencies = [self.BUILD_DSP_G],
                    linkedGet    = lambda read, i=i : bDspGet(read,i)
                ))

            self.add(self.enableDeps[i])

        #########
        # Devices
        #########
        for i in range(2):
            if ((numRxLanes[i] > 0) or (numTxLanes[i] > 0)):
                self.add(AmcMicrowaveMuxCore(
                    name    = "MicrowaveMuxCore[%i]" % (i),
                    offset  = (i*0x00400000),
                    expand  = True,
                ))

        self.add(sysgenClass(offset     = 0x01000000,
                             enableDeps = self.enableDeps,
                             expand     = True))

        self.add(RtmCryoDet(offset     = 0x02000000,
                            expand     = False))

        self.add(TimingHeader(offset   = 0x04000000,
                              expand   = False))

        ###########
        # Registers
        ###########

        self.add(pr.RemoteVariable(
            name         = "enableStreaming",
            description  = "Enable streaming",
            offset       = 0x03000008,
            bitSize      = 1,
            bitOffset    = 0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "DebugSelect[0]",
            description  = "Select which Band goes to DaqMuxV2[0] debug",
            offset       = 0x03000008,
            bitSize      = 2,
            bitOffset    = 1,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "DebugSelect[1]",
            description  = "Select which Band goes to DaqMuxV2[1] debug",
            offset       = 0x03000008,
            bitSize      = 2,
            bitOffset    = 3,
            base         = pr.UInt,
            mode         = "RW",
        ))


        ##############################
        # Commands
        ##############################
        def Init(self):
            amcCores = self.find(typ=AmcMicrowaveMuxCore)
            for core in amcCores:
                core.InitAmcCard()

        def Disable(self):
            amcCores = self.find(typ=AmcMicrowaveMuxCore)
            for core in amcCores:
                core.LMK.enable.set(True)
                core.LMK.PwrDwnSysRef()
